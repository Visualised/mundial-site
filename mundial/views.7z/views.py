import json
from rest_framework import mixins
from rest_framework.generics import GenericAPIView
from rest_framework.views import APIView
from rest_framework.response import Response
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.views import View
from .models import Player as PlayerModel
from .models import Country as CountryModel
from .serializers import PlayerSerializer, CountrySerializer

# Create your views here.

#zrobic abstrakcyjny widok i z niego dziedziczyc

class Player(
    mixins.ListModelMixin, 
    mixins.CreateModelMixin, 
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.DestroyModelMixin,
    GenericAPIView):

    serializer_class = PlayerSerializer
    queryset = PlayerModel.objects.all()

    def get(self, request, pk = None):
        if pk:
            return self.retrieve(request)
        else:
            return self.list(request)

    def post(self, request, pk):
        if pk:
            return HttpResponse("Please use PATCH method to update Player data.", status=400)
        return self.create(request)

    def put(self, request, pk):
        return self.update(request)

    def patch(self, request, pk):
        return self.partial_update(request)

    def delete(self, request, pk):
        return self.destroy(request)


class Country(
    mixins.ListModelMixin, 
    mixins.CreateModelMixin, 
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.DestroyModelMixin,
    GenericAPIView):

    serializer_class = CountrySerializer
    queryset = CountryModel.objects.all()

    def get(self, request, pk = None):
        if pk:
            return self.retrieve(request)
        else:
            return self.list(request)

    def post(self, request, pk = None):
        if pk:
            return HttpResponse("Please use PATCH method to update Country data.", status=400)
        return self.create(request)

    def put(self, request, pk = None):
        if not pk:
            return HttpResponse("Please specify Country ID in order to update data.", status=400)
        return self.update(request)

    def patch(self, request, pk = None):
        if not pk:
            return HttpResponse("Please specify Country ID in order to update data.", status=400)
        return self.partial_update(request)

    def delete(self, request, pk = None):
        if not pk:
            return HttpResponse("Please specify Country ID in order to delete data.", status=400)
        return self.destroy(request)

# class Match(mixins.ListModelMixin, mixins.CreateModelMixin, GenericAPIView):
    
#     serializer_class = 
   
#     def get(self, request):
#         return self.list(request, )

#     def post(self, request):
#         json_data = json.loads(request.body)
#         new_match = MatchModel.objects.create(**json_data)
#         new_match.save()
#         return HttpResponse("Match has been added.", status=201)



# class Player(APIView):

#     def get(self, request, id_ = None):
#         if id_:
#             # player_test = PlayerModel.objects.get(pk=self.id_from_url)
#             # print(player_test)
#             # serializer = PlayerSerializer(player_test)
#             # print(serializer.data)
#             player = PlayerModel.objects.filter(pk=id_).values().first()
#             return JsonResponse(player, safe=False)
#         else:
#             player_list = list(PlayerModel.objects.values())
#             return JsonResponse(player_list, safe=False)
    

#     def post(self, request, id_ = None):
#         if id_:
#             return HttpResponse("Please use PATCH method to update Player data.")

#         json_data = json.loads(request.body)
#         new_player = PlayerModel.objects.create(**json_data)
#         new_player.save()
#         return HttpResponse("Player has been added.", status=201)
    
#     def patch(self, request, id_ = None):
#         if not id_:
#             return HttpResponse("Please specify Player ID in order to update data.")
        
#         json_data = json.loads(request.body)
#         player = PlayerModel.objects.get(pk=id_)
#         serializer = PlayerSerializer(player, data=json_data)
#         if serializer.is_valid():
#             serializer.save()
#             return HttpResponse("Zapisałem")

#         return HttpResponse("Nie zapisałem")

#     def delete(self, request, id_ = None):
        # if not id_:
        #     return HttpResponse("Please specify Player ID in order to delete data.")
        
#         player = PlayerModel.objects.get(pk=id_)
#         player.delete()
#         return HttpResponse(f"Player {player} has been deleted")
